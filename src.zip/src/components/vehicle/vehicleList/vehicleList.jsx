import { width } from 'dom-helpers';
import React, { Component } from 'react';
import vehicleService from '../../../Services/vehicleService';
import styles from "./vehicleList.module.css";
import swal from 'sweetalert';

class vehicleList extends Component {
    constructor(props){
        super(props)

        this.state = {
            vehicles: [],
            searchRegistrationNo: ""
        }
        this.addVehicle = this.addVehicle.bind(this);
        this.editVehicle = this.editVehicle.bind(this);
        this.deleteVehicle = this.deleteVehicle.bind(this);
     
        this.searchRegistrationNo = this.searchRegistrationNo.bind(this);
        this.onChangesearchRegistrationNo = this.onChangesearchRegistrationNo.bind(this);
        this.generateReport = this.generateReport.bind(this);
        
    }
    
    deleteVehicle(id){


        swal({
            title: "Are you sure?",
            text: "Once deleted, this cannot be recovered!",
            icon: "warning",
            buttons: true,
            dangerMode: true, }).then((willDelete) => {
            if (willDelete) {
            swal("Successfully deleted", {
            icon: "success",
            });

        //rest api
        vehicleService.deleteVehicle(id).then( res => {
            this.setState({vehicles: this.state.vehicles.filter(vehicle => vehicle.vehicleId !== id)});
        });

        } else {
            swal("Cancelled!");
            }
        });
    }
 
    viewVehicle(id){
        this.props.history.push(`/view-vehicle/${id}`);
    }

    editVehicle(id){
        this.props.history.push(`/add-vehicle/${id}`);
    }

    componentDidMount(){
        vehicleService.getVehicles().then((res) => {
            this.setState({vehicles :res.data});
        });

    }

    addVehicle() {
        this.props.history.push('/add-vehicle/_add');       
        
    }

    searchRegistrationNo(){
        vehicleService.findByRegistrationNo(this.state.searchRegistrationNo)
        .then(response => {
            this.setState({
                vehicles: response.data
        });
        console.log(response.data);
    })
    .catch(e => {
        console.log(e);
    });
}

onChangesearchRegistrationNo(e){
        const searchRegistrationNo = e.target.value;

        this.setState({
            searchRegistrationNo: searchRegistrationNo
        });
    }

generateReport (){

    vehicleService.generateVehicleReport();
    swal("Report is generated", "", "success")
}   
    
render() {
        const{searchRegistrationNo} = this.state
        return (
            <div ><br/>
                <h2 className= "text-left">Vehicle List</h2>
                    <br/>
                    <button 
                    style = {{ width: '150px', height: '50px', float:'left' }} 
                    className = "btn btn-primary" onClick = {this.addVehicle}>Add Vehicle</button>
                
            <div style = {{ float:'center',paddingTop:'0%', paddingLeft:'1060px'}}>
                <input 
                style = {{ width: '300px' ,height: '50px'}}
                type="text"
                className="form-control"
                placeholder="Search by registration no"
                value={searchRegistrationNo}
                onChange={this.onChangesearchRegistrationNo}
                />
            
           
                <button
                className="input-group-append"
                style = {{ width: '150px' ,height: '50px', marginBottom:'5px'}}
                className="btn btn-info"
                type="button"
                onClick={this.searchRegistrationNo}>
                    Search
                </button>
            </div>

        
            <button 
             style = {{ width: '150px', height: '50px', float:'left' }} 
             onClick = { () => this.generateReport()} 
             className = "btn btn-secondary">Report</button>
<br/><br/><br/>

                <div className = "row">
                    <table className = "table table-striped table-bordered">
                      
                        <thead>
                            <tr>
                                <th>Registration Number</th>
                                <th>Name of the owner</th>
                                <th>Year of Manufacture</th>
                                <th>Model</th>
                                <th>Actions</th>                                
                            </tr>
                        </thead>

                        <tbody>
                            {
                                this.state.vehicles.map(
                                    vehicle =>
                                    <tr key = {vehicle.vehicleId}>
                                        <td className = {styles.aligning}>{vehicle.registrationNo}</td>
                                        <td className = {styles.aligning}>{vehicle.nameOfTheOwner}</td>
                                        <td className = {styles.aligning}>{vehicle.yearOfManufacture}</td>   
                                        <td className = {styles.aligning}>{vehicle.model}</td>   
                                        <td className = {styles.actions}>
                                          

                                            <div class="container">
                                            <div class="row">
                                            
                                            <div class="col">
                                            <button onClick = { () => this.editVehicle(vehicle.vehicleId)} className = "btn btn-info" >Update</button>
                                                                                    
                                                </div>
                                            <div class="col">
                                            <button  onClick = { () => this.viewVehicle(vehicle.vehicleId)} className = "btn btn-warning" >View</button>
                                                                                    
                                                </div>
                                            <div class="col">
                                            <button  onClick = { () => this.deleteVehicle(vehicle.vehicleId)} className = "btn btn-danger" >Delete</button>
                                                                                    
                                                </div></div></div>
                                           
                                        </td>                                    
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>

            </div>
        );
    }
}

export default vehicleList;