package com.example.demo.Model;

public class S_Invoice {

}
