package com.example.demo.Model;

public class H_Customer {

}
