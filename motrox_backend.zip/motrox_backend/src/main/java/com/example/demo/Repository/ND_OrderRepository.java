package com.example.demo.Repository;

public interface ND_OrderRepository {

}
