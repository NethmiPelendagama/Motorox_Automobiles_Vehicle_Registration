package com.example.demo.Repository;

public interface S_InvoiceRepository {

}
