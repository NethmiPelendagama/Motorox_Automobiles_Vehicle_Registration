package com.example.demo.Repository;

public interface H_CustomerRepository {

}
