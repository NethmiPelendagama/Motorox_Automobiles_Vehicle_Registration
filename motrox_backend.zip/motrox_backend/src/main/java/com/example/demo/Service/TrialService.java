package com.example.demo.Service;

public class TrialService {
	private int firstandlast;
	private String email;
	private String anushi;
	private String num;
}
