package com.example.demo.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.example.demo.Model.N_Vehicle;
import com.example.demo.Repository.N_VehicleRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class N_VehicleService {

	@Autowired
	private N_VehicleRepository repository;
	
	public String exportReport(String reportFormat) throws FileNotFoundException, JRException {
	
		String path = "C:\\Users\\Nethmi Pelendagama\\Desktop\\VehiclesReport";
	
		List<N_Vehicle> vehicle = repository.findAll();
	
	//load file and compile
		File file = ResourceUtils.getFile("classpath:N_Vehicle.jrxml");
		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(vehicle);
		
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("createdBy", "Motorox");
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
		
		if(reportFormat.equalsIgnoreCase("html")) {
		JasperExportManager.exportReportToHtmlFile(jasperPrint, path + "\\vehicles_report.html");
		}
		
		if(reportFormat.equalsIgnoreCase("pdf")) {
		JasperExportManager.exportReportToPdfFile(jasperPrint, path + "\\vehicles_report.pdf");
		}
		return "report generated in path : " + path;
		}
}
